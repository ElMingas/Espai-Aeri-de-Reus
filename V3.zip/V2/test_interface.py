from test_graph import g
from interface import *

create_interactive_interface(g)